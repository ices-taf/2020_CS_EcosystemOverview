# icesFO 1.0.0.9003

- Internal changes and bug fixes only.


# icesFO 1.0.0.9002

* add plot_sar_map() and load_sar_map()
* rename and simplify plot_ecoregion_map()
* update format_catches() to not do any downloading on the fly
* add function load_asfis_species()
* add load_areas and load_ecoregion functions that utilise GIS REST
* add plot_effort_map() function


# icesFO 1.0.0.9001

- Same as previous version.


# icesFO 1.0.0.9000

- First version


