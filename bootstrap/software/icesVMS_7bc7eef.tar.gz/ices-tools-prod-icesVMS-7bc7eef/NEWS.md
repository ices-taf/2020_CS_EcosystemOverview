# icesVMS 1.0.0.9006

* add get_wgfbit_data2()


# icesVMS 1.0.0.9005

* added function get_wgfbit_data1()
* add get_sar_map() function


# icesVMS 1.0.0.9004

* add get_fo_landings()


# icesVMS 1.0.0.9003

* add get_effort_map() function


# icesVMS 1.0.0.9002

* add get_fo_effort() fisheries overviews effort function
* add get_square() function


# icesVMS 1.0.0.9001

* write jwt.token to tempdir
* add filtering args to get_vms() function


# icesVMS 1.0.0.9000

- Internal changes only.


